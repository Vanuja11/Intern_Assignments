package com.hSenid.vanuja.springBootDemo.SpringLearning

import org.junit.jupiter.api.Test
import org.springframework.boot.test.context.SpringBootTest

@SpringBootTest
class SpringLearningApplicationTests {

	@Test
	fun contextLoads() {
	}

}
